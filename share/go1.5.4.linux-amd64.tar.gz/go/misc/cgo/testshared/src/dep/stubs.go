//+build !gccgo

package dep

func ImplementedInAsm()
